## Assignment 4: Implement Berkeley algorithm for clock synchronization.

#### Terminal 1: Running the Server (Master Node)


   Execute the following command to start the Client:
   ```
   python Client.py
   ```

### Terminal 2: Running the Client (Slave Nodes)

   Execute the following command to start the Server:
   ```
   python Server.py
   ```

